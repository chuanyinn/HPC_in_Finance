# Jarrow-Rudd binomial tree

## Introduction
The Jarrow-Rudd binomial tree is a method used for option pricing, similar to the Cox-Ross-Rubinstein (CRR) binomial tree, but with some differences in the way up and down movements of the underlying asset are calculated. The Jarrow-Rudd model uses the actual probability measure (as opposed to the risk-neutral measure in CRR) and is used for both European and American options.

Input Parameters:
- `S0`: Initial stock price.
- `K`: Strike price.
- `T`: Time to maturity in years.
- `r`: Risk-free interest rate.
- `sigma`: Volatility.
- `N`: Number of time steps.
- `option_type`: 'call' for a call option, 'put' for a put option.

Function Parameters:
- `dt`: Time step size.
- `u`, `d`: Up and down factors.
- `p`: Probability of an up movement.
- `asset_prices`: Matrix to store the underlying asset prices at each node.
- `option_values`: Matrix to store the option values at each node.

Algorithm:
- Asset Price Calculation: Populate the asset_prices matrix.
- Option Value Calculation: Populate the option_values matrix at maturity and work backward to the present value.

## How to Use the Program
Build

Run

## Optimization
Original:

Improvement 1:

Improvement 2:
